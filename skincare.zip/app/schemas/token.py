# app/schemas/token.py
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime, timedelta

class Token(BaseModel):
    """
    Model untuk representasi token akses
    """
    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field(default="bearer", description="Tipe token")

class TokenData(BaseModel):
    """
    Model untuk data yang disimpan dalam token
    """
    username: Optional[str] = Field(default=None, description="Username pengguna")
    user_id: Optional[int] = Field(default=None, description="ID pengguna")
    email: Optional[str] = Field(default=None, description="Email pengguna")
    expires_at: Optional[datetime] = Field(default=None, description="Waktu kedaluwarsa token")

class RefreshToken(BaseModel):
    """
    Model untuk refresh token
    """
    refresh_token: str = Field(..., description="Refresh token")
    access_token: Optional[str] = Field(default=None, description="New access token")

class TokenCreate(BaseModel):
    """
    Model untuk membuat token
    """
    user_id: int = Field(..., description="ID pengguna")
    token_type: str = Field(default="access", description="Tipe token")
    expires_delta: Optional[timedelta] = Field(
        default=timedelta(minutes=15), 
        description="Durasi token"
    )

class TokenBlacklist(BaseModel):
    """
    Model untuk token yang di-blacklist
    """
    token: str = Field(..., description="Token yang di-blacklist")
    blacklisted_at: datetime = Field(default_factory=datetime.utcnow, description="Waktu token di-blacklist")
    expires_at: Optional[datetime] = Field(default=None, description="Waktu kedaluwarsa token")

# Contoh fungsi utility untuk token
def create_access_token(
    data: dict, 
    secret_key: str, 
    algorithm: str = "HS256", 
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Fungsi untuk membuat access token
    
    :param data: Data yang akan disimpan dalam token
    :param secret_key: Kunci rahasia untuk signing
    :param algorithm: Algoritma enkripsi
    :param expires_delta: Durasi token
    :return: Token terenkripsi
    """
    from datetime import datetime, timedelta
    from jose import jwt

    to_encode = data.copy()
    
    # Set expiration time
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        # Default expiration 15 menit
        expire = datetime.utcnow() + timedelta(minutes=15)
    
    to_encode.update({"exp": expire})
    
    # Encode token
    encoded_jwt = jwt.encode(
        to_encode, 
        secret_key, 
        algorithm=algorithm
    )
    
    return encoded_jwt

def decode_token(
    token: str, 
    secret_key: str, 
    algorithms: list = ["HS256"]
) -> dict:
    """
    Fungsi untuk mendekode token
    
    :param token: Token yang akan didekode
    :param secret_key: Kunci rahasia untuk verifikasi
    :param algorithms: Algoritma dekripsi
    :return: Data yang terkandung dalam token
    """
    from jose import jwt
    from jose.exceptions import JWTError

    try:
        payload = jwt.decode(
            token, 
            secret_key, 
            algorithms=algorithms
        )
        return payload
    except JWTError:
        return None