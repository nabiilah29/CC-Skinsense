from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from datetime import datetime

class SurveySubmission(BaseModel):
    jawaban: List[int] = Field(
        ..., 
        min_items=14, 
        max_items=14,
        description="Jawaban survey dengan 14 elemen"
    )

    @classmethod
    def validate_jawaban(cls, v):
        for item in v:
            if item < 1 or item > 4:
                raise ValueError("Setiap jawaban harus antara 1-4")
        return v

# app/schemas/survey.py
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional

class PredictionItem(BaseModel):
    name: str
    score: float
    
    # Tambahkan konfigurasi untuk memastikan validasi
    model_config = ConfigDict(
        from_attributes=True,  # Memungkinkan konversi dari objek lain
        populate_by_name=True  # Memungkinkan populate dengan nama field
    )

class SurveyPredictionResponse(BaseModel):
    produk: List[PredictionItem] = Field(default_factory=list)
    fitur: List[PredictionItem] = Field(default_factory=list)
    bahan: List[PredictionItem] = Field(default_factory=list)
    
    # Tambahkan konfigurasi
    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True
    )

# Tambahan untuk input survey
class SurveySubmission(BaseModel):
    jawaban: List[int] = Field(..., min_length=14, max_length=14)

class SurveyHistoryResponse(BaseModel):
    id: int
    created_at: datetime
    prediction_summary: Dict[str, List[str]]

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True
    )