from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime

class UserLogin(BaseModel):
    username: str  # Bisa username atau email
    password: str

    @validator('username')
    def username_not_empty(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Username tidak boleh kosong')
        return v.strip()

    @validator('password')
    def password_not_empty(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Password tidak boleh kosong')
        return v

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    age: Optional[int] = None

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    full_name: Optional[str] = None
    age: Optional[int] = None
    created_at: datetime

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    age: Optional[int] = None

from app.models.user import User