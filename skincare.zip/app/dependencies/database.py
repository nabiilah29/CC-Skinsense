from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session, declarative_base
from contextlib import contextmanager
from typing import Generator

from app.config import settings

Base = declarative_base()

# Engine dengan pool koneksi yang lebih baik untuk MySQL
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,  # Cek koneksi sebelum digunakan
    pool_recycle=3600,   # Daur ulang koneksi setiap jam
    pool_size=10,        # Ukuran pool koneksi
    max_overflow=20      # Koneksi tambahan jika pool penuh
)

# Buat SessionLocal
SessionLocal = sessionmaker(
    autocommit=False, 
    autoflush=False, 
    bind=engine
)

# Generator database session
def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_tables():
    """
    Fungsi untuk membuat semua tabel yang didefinisikan dalam model.
    """
    from app.models import user, survey  # Import model-model Anda
    Base.metadata.create_all(bind=engine)

# Context manager untuk database session
@contextmanager
def get_db_context():
    """Context manager untuk session database"""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()