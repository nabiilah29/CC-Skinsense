import json
import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from requests import Session

from app.models.user import User
from app.dependencies.database import get_db
from app.schemas.survey import SurveySubmission, SurveyPredictionResponse, SurveyHistoryResponse, PredictionItem
from app.services import survey_service, auth_service
from app.services.survey_service import SurveyService
from app.ml.predictor import MLPredictor
from app.utils.security import get_current_active_user

router = APIRouter()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Definisikan path model
MODEL_PATH = 'app/ml/models/skincare_model.tflite'
SCALER_PATH = 'app/ml/models/scaler.joblib'
BINARIZER_PATH = 'app/ml/models/binarizers.joblib'

try:
    print(BINARIZER_PATH)
    ml_predictor = MLPredictor(
        model_path=MODEL_PATH, 
        scaler_path=SCALER_PATH, 
        binarizer_path=BINARIZER_PATH
    )
except Exception as e:
    logger.error(f"Failed to initialize ML Predictor: {e}")
    ml_predictor = None

@router.post("/survey", response_model=SurveyPredictionResponse)
async def submit_survey(
    survey_data: SurveySubmission,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    # Pastikan ml_predictor tidak None
    if ml_predictor is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Model prediksi tidak tersedia"
        )

    survey_service = SurveyService(db)
    
    try:
        db_survey_response = survey_service.create_survey_response(
            current_user.id, 
            survey_data.jawaban, 
            ml_predictor
        )
        
        # Parse prediction result
        prediction_result = json.loads(db_survey_response.prediction_result)
        
        # Konversi ke response model
        return SurveyPredictionResponse(
            produk=[
                {"name": name, "score": score} 
                for name, score in zip(
                    prediction_result['prediction']['produk']['classes'], 
                    prediction_result['prediction']['produk']['scores']
                )
            ],
            fitur=[
                {"name": name, "score": score} 
                for name, score in zip(
                    prediction_result['prediction']['fitur']['classes'], 
                    prediction_result['prediction']['fitur']['scores']
                )
            ],
            bahan=[
                {"name": name, "score": score} 
                for name, score in zip(
                    prediction_result['prediction']['bahan']['classes'], 
                    prediction_result['prediction']['bahan']['scores']
                )
            ]
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail=str(e)
        )

@router.get("/survey/history", response_model=List[SurveyHistoryResponse])
async def get_survey_history(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    try:
        survey_service = SurveyService(db)
        survey_history = survey_service.get_survey_history(db, current_user.id)
        return survey_history
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail=str(e)
        )

@router.get("/survey/{survey_id}", response_model=SurveyPredictionResponse)
async def get_survey_prediction(
    survey_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    try:
        survey_service = SurveyService(db)
        survey_prediction = survey_service.get_survey_prediction(db, current_user.id, survey_id)
        return survey_prediction
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Survey tidak ditemukan"
        )