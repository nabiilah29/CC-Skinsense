# app/routes/user_routes.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.dependencies.database import get_db
from app.models.user import User
from app.schemas import UserResponse, UserUpdate
from app.services import user_service
from app.utils.security import get_current_active_user

router = APIRouter(prefix="/users", tags=["Users"])

@router.get("/", response_model=List[UserResponse])
async def read_users(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Retrieve list of users (hanya bisa diakses oleh user aktif)
    """
    users = user_service.get_users(db, skip=skip, limit=limit)
    return users

@router.get("/me", response_model=UserResponse)
async def read_user_me(
    current_user: User = Depends(get_current_active_user)
):
    """
    Mendapatkan informasi user yang sedang login
    """
    return current_user

@router.put("/me", response_model=UserResponse)
async def update_user_me(
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Update informasi user yang sedang login
    """
    updated_user = user_service.update_user(
        db, 
        current_user.id, 
        user_update
    )
    return updated_user

@router.delete("/me", response_model=dict)
async def delete_user_me(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Hapus akun user yang sedang login
    """
    user_service.delete_user(db, current_user.id)
    return {"detail": "User account deleted successfully"}

@router.get("/{user_id}", response_model=UserResponse)
async def read_user(
    user_id: int, 
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Mendapatkan detail user berdasarkan ID (hanya bisa diakses oleh user aktif)
    """
    user = user_service.get_user_by_id(db, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user