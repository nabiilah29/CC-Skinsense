import json
import logging
from typing import List
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from app.models.survey import SurveyResponse
from app.schemas.survey import SurveySubmission, SurveyPredictionResponse, SurveyHistoryResponse
from app.ml.predictor import MLPredictor

class SurveyService:
    def __init__(self, db: Session):
        """
        Inisialisasi SurveyService dengan database session
        """
        self.db = db
        self.logger = logging.getLogger(__name__)

    def create_survey_response(
        self, 
        user_id: int, 
        jawaban: List[int], 
        ml_predictor: MLPredictor
    ) -> SurveyResponse:
        """
        Membuat respons survey dengan prediksi
        """
        try:
            # Validasi input
            if not isinstance(jawaban, list):
                raise ValueError("Jawaban harus berupa list")
            
            if len(jawaban) != 14:
                raise ValueError("Jawaban harus berisi 14 item")
            
            # Pastikan semua item adalah integer antara 1-4
            if not all(1 <= item <= 4 for item in jawaban):
                raise ValueError("Setiap jawaban harus antara 1-4")
            
            # Lakukan prediksi
            prediction_result = ml_predictor.predict(jawaban)

            full_response = {
                'status': 'success',
                'survey_response_id': None,  # Akan diisi setelah commit
                'prediction': prediction_result
            }
            
            # Konversi ke JSON string
            survey_data = json.dumps({'jawaban': jawaban})
            prediction_result_str = json.dumps(full_response)
            
            # Buat objek survey response
            survey_response = SurveyResponse(
                user_id=user_id,
                survey_data=survey_data,
                prediction_result=prediction_result_str,
                is_processed=True
            )
            
            # Simpan ke database
            self.db.add(survey_response)
            self.db.commit()
            self.db.refresh(survey_response)
            
            full_response['survey_response_id'] = survey_response.id
            survey_response.prediction_result = json.dumps(full_response)
            self.db.commit()
            
            return survey_response
        
        except Exception as e:
            self.db.rollback()
            self.logger.error(f"Error creating survey response: {e}")
            raise

    def get_survey_prediction(self, survey_response_id):
        """
        Mengambil respons survey dengan parsing JSON yang benar
        """
        survey_response = self.db.query(SurveyResponse).get(survey_response_id)
        
        # Parse survey data
        survey_data = json.loads(survey_response.survey_data)
        prediction_result = json.loads(survey_response.prediction_result)
        
        return {
            'survey_data': survey_data,
            'prediction_result': prediction_result
        }

    # def get_survey_prediction(
    #     self, 
    #     user_id: int, 
    #     survey_id: int
    # ) -> dict:
    #     """
    #     Mendapatkan prediksi survey berdasarkan ID
    #     """
    #     try:
    #         db_survey_response = self.db.query(SurveyResponse).filter(
    #             SurveyResponse.id == survey_id,
    #             SurveyResponse.user_id == user_id
    #         ).first()

    #         if not db_survey_response:
    #             raise ValueError("Survey tidak ditemukan")

    #         # Parse JSON string kembali ke dictionary
    #         return json.loads(db_survey_response.prediction_result)
        
    #     except Exception as e:
    #         self.logger.error(f"Error getting survey prediction: {e}")
    #         raise

    def get_survey_history(self, db: Session, user_id: int) -> List[SurveyHistoryResponse]:
        try:
            # Query survey history
            surveys = db.query(SurveyResponse).filter(
                SurveyResponse.user_id == user_id
            ).order_by(SurveyResponse.submitted_at.desc()).all()

            # Transformasi ke response model
            history = []
            for survey in surveys:
                try:
                    # Parse prediction result dengan metode yang fleksibel
                    prediction = json.loads(survey.prediction_result)
                    
                    # Debug print
                    print("Full Prediction:", prediction)
                    
                    # Ekstrak ringkasan prediksi
                    prediction_summary = extract_prediction_summary(prediction)

                    history.append(SurveyHistoryResponse(
                        id=survey.id,
                        created_at=survey.submitted_at,
                        prediction_summary=prediction_summary
                    ))
                except Exception as survey_error:
                    # Log error untuk survey individual
                    self.logger.error(f"Error processing survey {survey.id}: {survey_error}")
                    # Log raw data untuk investigasi
                    self.logger.error(f"Raw prediction data: {survey.prediction_result}")
                    # Lanjutkan ke survey berikutnya
                    continue

            return history

        except Exception as e:
            self.logger.error(f"Error fetching survey history: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Gagal mengambil riwayat survey: {str(e)}"
            )

# Fungsi standalone untuk kasus tertentu (opsional)
def create_survey_response(
    db: Session,
    user_id: int,
    jawaban: List[int],
    ml_predictor: MLPredictor
) -> SurveyResponse:
    """
    Fungsi alternatif untuk membuat survey response
    """
    service = SurveyService(db)
    return service.create_survey_response(user_id, jawaban, ml_predictor)


def extract_prediction_summary(prediction_data):
    """
    Fungsi untuk mengekstrak prediksi dengan berbagai struktur JSON
    """
    try:
        # Coba berbagai struktur JSON
        if 'prediction' in prediction_data:
            prediction = prediction_data['prediction']
        elif 'prediksi' in prediction_data:
            prediction = prediction_data['prediksi']
        else:
            prediction = prediction_data

        # Ekstrak kelas prediksi
        produk_classes = (
            prediction.get('produk', {}).get('classes', []) or 
            prediction.get('Produk', {}).get('Classes', [])
        )[:3]

        fitur_classes = (
            prediction.get('fitur', {}).get('classes', []) or 
            prediction.get('Fitur', {}).get('Classes', [])
        )[:3]

        bahan_classes = (
            prediction.get('bahan', {}).get('classes', []) or 
            prediction.get('Bahan', {}).get('Classes', [])
        )[:3]

        return {
            'produk': produk_classes,
            'fitur': fitur_classes,
            'bahan': bahan_classes
        }
    except Exception as e:
        print(f"Error extracting prediction: {e}")
        print(f"Raw prediction data: {prediction_data}")
        return {
            'produk': [],
            'fitur': [],
            'bahan': []
        }