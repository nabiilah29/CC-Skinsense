from sqlalchemy import Column, Integer, String, Text, JSON, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy.dialects.mysql import LONGTEXT
from app.database import Base

# class Survey(Base):
#     __tablename__ = "surveys"

#     id = Column(Integer, primary_key=True, index=True)
#     title = Column(String(200), nullable=False)
#     description = Column(Text, nullable=True)
    
#     # Metadata survey
#     is_active = Column(Boolean, default=True)
#     start_date = Column(DateTime(timezone=True), nullable=True)
#     end_date = Column(DateTime(timezone=True), nullable=True)
    
#     # Struktur survey dalam JSON atau LONGTEXT untuk data besar
#     survey_structure = Column(LONGTEXT, nullable=False)
    
#     # Timestamps
#     created_at = Column(DateTime(timezone=True), server_default=func.now())
#     updated_at = Column(DateTime(timezone=True), onupdate=func.now())

#     # Relasi dengan responses
#     responses = relationship("SurveyResponse", back_populates="survey")

#     def __repr__(self):
#         return f"<Survey {self.title}>"
    

class SurveyResponse(Base):
    __tablename__ = "survey_responses"

    id = Column(Integer, primary_key=True, index=True)
    
    # Foreign Keys
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    
    # Jawaban dalam format JSON atau LONGTEXT
    survey_data = Column(JSON, nullable=False)
    
    prediction_result = Column(JSON)
    # Status dan metadata
    is_processed = Column(Boolean, default=False)
    
    # Timestamps
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    user = relationship("User", back_populates="survey_responses")

