import numpy as np
import joblib
import tensorflow as tf
import logging
import traceback
import json

class MLPredictor:
    def __init__(self, model_path, scaler_path, binarizer_path):
        """
        Inisialisasi MLPredictor dengan model TFLite, scaler, dan binarizers
        """
        try:
            # Setup logging
            logging.basicConfig(level=logging.INFO)
            self.logger = logging.getLogger(__name__)

            # Load TFLite model
            self.interpreter = tf.lite.Interpreter(model_path=model_path)
            self.interpreter.allocate_tensors()
            
            # Get input and output details
            self.input_details = self.interpreter.get_input_details()
            self.output_details = self.interpreter.get_output_details()
            
            # Load scaler
            self.scaler = joblib.load(scaler_path)
            
            # Load binarizers
            self.binarizers = joblib.load(binarizer_path)
            
            # Definisi kelas untuk setiap label
            self.label_classes = {
                'produk': ['Booster', 'Calming Mask', 'Cleanser', 'Essence', 'Mask', 
                           'Moisturizer', 'Serum', 'Spot Treatment', 'Sunscreen', 'Toner'],
                'fitur': ['Acne Free', 'Acne Prevention', 'Acne Treatment', 'Balanced', 
                          'Balanced Hydration', 'Balancing', 'Calming', 'Custom Care', 
                          'Hydrating', 'Minimal Care', 'Oil Control', 'Pore Care', 
                          'Protective', 'Soothing', 'UV Protection'],
                'bahan': ['Allantoin', 'Aloe Vera', 'Bakuchiol', 'Ceramide', 'Cica', 
                          'Glycerin', 'Glycol', 'Niacinamide', 'Panthenol', 
                          'Retinol', 'Salicylic Acid', 'Water']
            }
            
            # Log model details
            self.log_model_details()
            
        except Exception as e:
            self.logger.error(f"Error initializing MLPredictor: {e}")
            self.logger.error(traceback.format_exc())
            raise

    def log_model_details(self):
        """
        Log detailed information about the model's input and output
        """
        self.logger.info("Model Input Details:")
        for i, detail in enumerate(self.input_details):
            self.logger.info(f"Input {i}:")
            self.logger.info(f"  Name: {detail['name']}")
            self.logger.info(f"  Shape: {detail['shape']}")
            self.logger.info(f"  Dtype: {detail['dtype']}")
        
        self.logger.info("\nModel Output Details:")
        for i, detail in enumerate(self.output_details):
            self.logger.info(f"Output {i}:")
            self.logger.info(f"  Name: {detail['name']}")
            self.logger.info(f"  Shape: {detail['shape']}")
            self.logger.info(f"  Dtype: {detail['dtype']}")

    def prepare_input(self, input_data):
        """
        Persiapkan input untuk prediksi dengan validasi komprehensif
        """
        try:
            # Ekstrak jawaban jika input adalah dictionary
            if isinstance(input_data, dict):
                input_data = input_data.get('jawaban', [])
            
            # Validasi tipe input
            if not isinstance(input_data, (list, np.ndarray)):
                raise ValueError(f"Invalid input type: {type(input_data)}")
            
            # Konversi ke numpy array
            input_array = np.array(input_data, dtype=np.float32)
            
            # Log informasi input
            self.logger.info(f"Input length: {len(input_array)}")
            
            # Cek input details
            input_shape = self.input_details[0]['shape']
            self.logger.info(f"Model input shape: {input_shape}")
            
            # Determine expected dimensions
            if len(input_shape) == 2:
                # [batch_size, features]
                expected_features = input_shape[1]
            elif len(input_shape) == 3:
                # [batch_size, time_steps, features]
                expected_features = input_shape[2]
            else:
                raise ValueError(f"Unexpected input shape: {input_shape}")
            
            self.logger.info(f"Expected features: {expected_features}")
            
            # Normalize/adjust input
            if len(input_array) > expected_features:
                # Truncate
                input_array = input_array[:expected_features]
            elif len(input_array) < expected_features:
                # Pad with last value or zeros
                padding = np.full(expected_features - len(input_array), input_array[-1])
                input_array = np.concatenate([input_array, padding])
            
            # Reshape for model input
            if len(input_shape) == 2:
                input_array = input_array.reshape(1, -1)
            elif len(input_shape) == 3:
                input_array = input_array.reshape(1, 1, -1)
            
            return input_array
        
        except Exception as e:
            self.logger.error(f"Input preparation error: {e}")
            self.logger.error(traceback.format_exc())
            raise

    def predict(self, jawaban, top_k=3):
        """
        Melakukan prediksi berdasarkan input survey
        
        Args:
            jawaban (dict/list): Data input survey
            top_k (int): Jumlah top prediksi
        
        Returns:
            dict: Prediksi untuk produk, fitur, dan bahan
        """
        try:
            # Persiapkan input
            processed_input = self.prepare_input(jawaban)
            
            # Scale input
            input_normalized = self.scaler.transform(processed_input)
            
            # Prepare input tensor
            input_tensor = input_normalized.astype(np.float32)
            
            # Set input tensor
            self.interpreter.set_tensor(self.input_details[0]['index'], input_tensor)
            
            # Run inference
            self.interpreter.invoke()
            
            # Hasil prediksi
            results = {}
            label_types = ['produk', 'fitur', 'bahan']
            
            for i, label in enumerate(label_types):
                # Ambil output untuk label saat ini
                pred = self.interpreter.get_tensor(self.output_details[i]['index'])
                
                # Flatten prediksi
                pred_flat = pred.flatten()
                
                # Log raw predictions
                self.logger.info(f"{label.capitalize()} Raw Prediction: {pred_flat}")
                
                # Gunakan softmax untuk normalisasi probabilitas
                pred_prob = tf.nn.softmax(pred_flat).numpy()
                
                # Log softmax probabilities
                self.logger.info(f"{label.capitalize()} Softmax Probabilities: {pred_prob}")
                
                # Validasi label classes
                label_class_list = self.label_classes[label]
                self.logger.info(f"{label.capitalize()} Available Classes: {label_class_list}")
                
                # Ambil top_k prediksi yang valid
                top_k_indices = []
                for idx in np.argsort(pred_prob)[::-1]:
                    if idx < len(label_class_list):
                        top_k_indices.append(idx)
                        if len(top_k_indices) == top_k:
                            break
                
                # Dapatkan kelas dan skor top_k
                predicted_classes = [label_class_list[idx] for idx in top_k_indices]
                predicted_scores = pred_prob[top_k_indices]
                
                results[label] = {
                    'classes': predicted_classes,
                    'scores': predicted_scores.tolist()
                }
                
                # Log prediksi
                self.logger.info(f"{label.capitalize()} Predicted Classes: {predicted_classes}")
                self.logger.info(f"{label.capitalize()} Prediction Scores: {predicted_scores}")

            return results

        except Exception as e:
            self.logger.error(f"Prediction Error: {e}")
            self.logger.error(traceback.format_exc())
            return {
                'produk': {'classes': [], 'scores': []},
                'fitur': {'classes': [], 'scores': []},
                'bahan': {'classes': [], 'scores': []}
            }